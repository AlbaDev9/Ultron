# patch-parse-ms

package parse-ms : https://www.npmjs.com/package/parse-ms


Homepage : https://github.com/sindresorhus/parse-ms#readme


Reposite : https://github.com/sindresorhus/parse-ms

# Comment installer ?
Pour installer c'est très simple, il vous suffit de cliquer sur le .zip, il sera automatiquement installer et il vous suffira de suivre le tutoriel par la suite.

Si vous ne voulez pas installer pas le .zip, vous pouvez exporter les fichiers un par un. Il vous faudra alors installer le index.ts, index.js, et le package.json.
